package com.company;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {

        int[] arr = {6, 40, 65, -3, 56, 100, 43};
        System.out.println(arr[3]);
        arr[4] = 111;
        System.out.println(arr[4]);
        //arr[8] = 99;
        System.out.println(Arrays.toString(arr));
        System.out.println(arr[1] + ", " + arr[4]);

        String[] names = new String[3];
        System.out.println(names[0]);
        names[0] = "Adil";
        names[1] = "Alina";
        names[2] = "Aygul";
        System.out.println(names[0]);
        System.out.println(Arrays.toString(names));

        double[][] digit2D = new double[3][4];
        digit2D[1][2] = -8.1;

        String[][] students = {{"Azim", "Radin"}, {"Alina", "Bermet"}};
    }
}
